function calcularOrcamento(precoPeca, horasTrabalho) {
    const valorHora = 85.00;
    const totalMaoDeObra = horasTrabalho * valorHora;

    return total = precoPeca + totalMaoDeObra;
}

function verificarGarantia(meses) {
    if (meses <=3) {
        return "Dentro da Garantia";
    }else {
        return "Fora da Garantia";
    }
}
//para o desconto criamos uma nova função
// o return garante a execução do cálculo e envio para o programa principal 
function comDesconto(valorBruto) {
    return valorBruto * 0.8
}

module.exports = {
    calcularOrcamento,
    verificarGarantia,
    comDesconto
};