const entrada = require('readline-sync')
const oficina = require('./funcoesOficina');

console.log("=== SISTEMA DE GESTAO DE OFICINA 1.0 ===");

const peca = entrada.questionFloat("Preco de peca: R$ ");
const horas = entrada.questionFloat("Horas de servico: ");
const tempoUso = entrada.questionFloat("Meses desde o ultimo conserto: ");

const total = oficina.calcularOrcamento(peca, horas);
//aplica 20% de desconto
const totalcomDesconto = oficina.comDesconto(total)

const garantia = oficina.verificarGarantia(tempoUso);

console.log("\n--- RELATORIO DE SERVICO ---");
console.log(`Orcamento total: R$ ${total.toFixed(2)}`);
console.log(`Orcamento total com desconto: R$ ${totalcomDesconto.toFixed(2)}`);
console.log(`Garantia        ${garantia}`);
console.log("---------------------------------------");